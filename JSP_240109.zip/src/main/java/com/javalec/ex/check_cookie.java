package com.javalec.ex;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class check_cookie
 */
public class check_cookie extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public check_cookie() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("id");
		String password = request.getParameter("pw");
		
		if(id.equals("admin")&&password.equals("1234")) {
			// 쿠키 :: 클라이언트(로컬 pc)에 저장하는 변수
			// 세션보다 보안에 좋지 않음
			// 사용자가 프로그램/브라우저를 꺼도 변수가 유지
			
			// 쿠키 객체 생성
			Cookie ck = new Cookie("id",id);
				//{id:"admin"} 형태로 cookie 객체 생성
			
			//쿠키 설정 -> 유효기간 설정(아래 같은 경우 30초로 설정)
			ck.setMaxAge(30);
			
			// 사용자 응답에 쿠키 객체 포함
			response.addCookie(ck);
			response.sendRedirect("welcome_cookie.jsp");
		}
		else {
			System.out.println("로그인 실패");
			response.sendRedirect("login_cookie.html");
		}
	}

}
