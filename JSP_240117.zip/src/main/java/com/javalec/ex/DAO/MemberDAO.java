package com.javalec.ex.DAO;

import java.sql.*;
import java.util.*;
import javax.naming.*;
import javax.sql.DataSource;

import com.javalec.ex.DTO.MemberDTO;

public class MemberDAO {
	private Connection conn=null;
	private Statement st = null;
	private ResultSet rs= null;
	private PreparedStatement ps=null;
	
	private DataSource ds=null;
	
	public MemberDAO() {
		try {
			//jdbc 드라버 로드
			Context ctx= new InitialContext();
			ds = (DataSource)ctx.lookup("java:comp/env/jdbc/mysql");	// 생성자
		}catch(Exception e) {
			System.out.println("MemberDAO 생성자 에러");
			e.printStackTrace();
		}
	}
	public void MemberInsert(String id, String pw, String name) {
		conn=null;
		ps=null;
		try {
			// DB 접속
			conn = ds.getConnection();
			//INSERT 구문 수행
			String query="insert into member values(?,?,?)";
			ps=conn.prepareStatement(query);
			ps.setString(1, id);
			ps.setString(2, pw);
			ps.setString(3, name);
			ps.executeUpdate();
		}catch(Exception e) {
			System.out.println("Insert 쿼리 실패");
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				conn.close();
			}catch(Exception e1) {
				System.out.println("객체 닫기 실패");
				e1.printStackTrace();
			}
		}
	}
	public void MemberDelete(String id) {
		conn=null;
		ps=null;
		try {
			// DB 접속
			conn = ds.getConnection();
			//INSERT 구문 수행
			String query="delete from member where id=?";
			ps=conn.prepareStatement(query);
			ps.setString(1, id);
			
			ps.executeUpdate();
		}catch(Exception e) {
			System.out.println("delete 쿼리 실패");
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				conn.close();
			}catch(Exception e1) {
				System.out.println("객체 닫기 실패");
				e1.printStackTrace();
			}
		}
	}
	public void MemberSelect(String id,String pw) {
		conn=null;
		ps=null;
		try {
			// DB 접속
			conn = ds.getConnection();
			//INSERT 구문 수행
			String query="select * from member where id=? and passwd=?";
			ps=conn.prepareStatement(query);
			ps.setString(1, id);
			ps.setString(2, pw);
			rs=ps.executeQuery();
			if(rs.next()) {
				System.out.println("성공");
			}
		}catch(Exception e) {
			System.out.println("select 쿼리 실패");
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				conn.close();
			}catch(Exception e1) {
				System.out.println("객체 닫기 실패");
				e1.printStackTrace();
			}
		}
	}
	public ArrayList<MemberDTO> MemberSelect(){
		ArrayList<MemberDTO> result = new ArrayList<MemberDTO>();
		conn=null;
		st=null;
		rs=null;
		try {
			conn=ds.getConnection();
			
			String query="select*from Member";
			st=conn.createStatement();
			rs=st.executeQuery(query);
			while(rs.next()) {
				MemberDTO element=new MemberDTO();
				element.setId(rs.getString("id"));
				element.setId(rs.getString("pw"));
				element.setId(rs.getString("name"));
				// element 객체에 데이터 한 묶음씩 저장하기
				result.add(element);
			}
		}catch(Exception e) {
			System.out.println("Select 쿼리 수행 실패");
			e.printStackTrace();
		}finally {
			try {
				conn.close();
				rs.close();
				st.close();
			}catch(Exception e1) {
				e1.printStackTrace();
			}
		}
		return result;
		
	}
}









