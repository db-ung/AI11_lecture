import java.util.Scanner;

public class Q_dayday {
	
	public static void getDaily(int m, int d) {	
		int i;
		int y=365;

		for(i=1; i < m; i++) {
			if(i == 2) {
				y-=28;
			}
			else if(i==1||i==3||i==5||i==7||i==8||i==10||i==12) {
				y-=31;
			}
			else {
				y-=30;
			}
		}
		y-=d;
		System.out.println(y);
				
	}
	// getDDaily 함수 :: 날짜 정보 통해, 연말까지 몇 일 남았는지 "반환"하는 함수
	public static int getDDaily(int m, int d) {
		// "365 - (1/1부터 현재 날짜까지의 일수)" 반환
		// 1. 1/1 ~ 현재 날짜까지의 일수 측정
		int count = 0;
		for(int i = 1; i < m; i++) {	// 1월부터 m월 이전까지 루프
			if(i==2) {
				count+=28;
			}
			else if(i==4 || i==6 || i==9 || i==11) {
				count+=30;
			}
			else {
				count+=31;
			}
		}
		count+=d;
		
		return 365-count;
		
		
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// 오늘 날짜(월, 일)를 입력받고
		// 이번 해가 끝나기까지 몇일이 남았는지 출력하기
		// getDaily 함수-> 
		
		System.out.println("오늘 날짜 입력해줘요");
		// 오늘 날짜(월, 일)를 입력받기
		int mo = sc.nextInt(); 	//월 정보
		int da = sc.nextInt();	//일 정보
		
		// 2. 연말까지 남은 일수 측정 및 출력 -> getDDaily 함수 호출
		System.out.println("연말까지 " +getDDaily(mo,da)+"일 남았습니다.");
		getDaily(mo,da);	//내가 한거
//		getDDaily(mo,da);	선생님이 하신거
		
		
	}

}
