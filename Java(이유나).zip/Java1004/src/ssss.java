import java.util.Scanner;
public class ssss {
	

	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        double A = sc.nextInt();

	        double B = sc.nextInt();

	        double c = A / B;
	        System.out.println(c);
	    }
	}

