
public class Overloading {
	public static int sum() {
		return 1 + 1;
	}
	public static int sum(int a) {
		return a + 1;
	}
	public static int sum(int a, int b) {
		return a + b;
	}
	
	public static void main(String[] args) {
		// 오버로딩 :: (함수에 적용되는 개념)
		// "매개변수 구성이 다르다면, 함수명을 같게 하여도 "함께 사용"할 수 있다."
		
		System.out.println("sum() 결과: "+sum());
		System.out.println("sum(n) 결과: "+sum(n));
		System.out.println("sum(n,n) 결과: "+sum(n,n));
	}
}
