import java.util.Scanner;

class clock {
	// 3개의 멤버 변수들이 모두 0으로 초기화한다.
	private int hour = 0;
	private int minute = 0;
	private int second = 0;
	
	//getter,setter
	public int getHour() {
		return hour;
	}
	public void setHour(int hour) {
		this.hour = hour;
	}
	public int getMinute() {
		return minute;
	}
	public void setMinute(int minute) {
		this.minute = minute;
	}
	public int getSecond() {
		return second;
	}
	public void setSecond(int second) {
		this.second = second;
	}
	
	// 멤버 함수 선언
	// PrintTime() :: 현재 시간 출력
	public void PrintTime() {
		System.out.println(this.hour+"시 "+this.minute+"분 "+this.second+"초");
		
		
	}
	
	// :: 현재 오후인지 오전인지
	public void AmPm() {
		if(this.hour>12 && this.hour<24) {
			System.out.println("오후");
		}
		
		else if(this.hour>=0 && this.hour<=12) {
			System.out.println("오전");
		}
		
	}
	
	public String AmPm1() {
		if(this.hour>12 && this.hour<24) {
			return "오후"
		}
		else {
			return "오전"
		}
	}
}

public class Q_Clock {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// c1, c2 객체 선언
		clock c1 = new clock();
		clock c2 = new clock();
		
		// 입력받기
		int hour = sc.nextInt();
		int minute = sc.nextInt();
		int second = sc.nextInt();
		
		// c2 객체 초기화
//		c2.setHour(sc.nextInt());	int형 입력 -> 함수 실행
		
		c2.setHour(hour);
		c2.setMinute(minute);
		c2.setSecond(second);
		
		// 출력
		c1.AmPm();
		c1.PrintTime();
		
		c2.AmPm();
		c2.PrintTime();
		
	}

}
