import java.util.Scanner;

//Account 클래스 구현
class Account{
	
	//멤버변수 선언
	private String id;
	private String password;
	private int acc_num;
	
	//메소드 선언
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getAcc_num() {
		return acc_num;
	}
	public void setAcc_num(int acc_num) {
		this.acc_num = acc_num;
	}
	
	// :: 3개 멤버 변수 값 출력
		public void print() {
			System.out.println("ID :: "+this.id);
			System.out.println("password :: "+this.password);
			System.out.println("회원번호 :: "+this.acc_num);
			
		}
	
	
	// 생성자1 :: 각각 초기화
	public Account() {
		this.id="0000";
		this.password="ex";
		this.acc_num=1111;
		
		this.print();
	}
	
	// 생성자2 :: 3개의  멤버 변수, 메개변수
	public Account(String i, String p, int a) {
		this.id = i;
		this.password = p;
		this.acc_num = a;
		
	}
	
	// :: 매개변수 값으로 password값 변경
	//비밀번호 변경 조건입력
	public void changePw() {
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			changePw(sc.next());
			if(this.password.length()<5) {
				System.out.println("다시");
			}
			else {
				System.out.println("성공");
				break;
			}
			
		}
		System.out.println("끝났습니다.");
	}
	
	//비밀번호 저장
	public void changePw(String pa) {
		this.password=pa;	
	}
	
	
	
}

public class Q_Account {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		// 1. 배열할당 >> 객체 생성
		Account manager[] = new Account[3]; 	//배열선언
		for(int i = 0; i < 3; i++) {
			manager[i] = new Account();		//객체 선언
		}
		
		// 2. id, password 코드 상에서 임의로 수정
		manager[0].setId("oh");		manager[0].setPassword("1234");
		manager[1].setId("oh1");	manager[1].setPassword("12343");
		manager[2].setId("oh2");	manager[2].setPassword("123444");
		
		
		// 3. manager[3] 순차적으로 정보 출력
		for(int i = 0; i < 3; i++) {
			manager[i].print();
			System.out.println();
		}
		
		// 4. user 객체 생성
		String id = sc.next();
		String pa = sc.next();
		int num = sc.nextInt();
		Account user = new Account(id,pa,num);
		System.out.println("완료되었습니다.");
			 
		// 5. user 정보 순차적으로 출력	
			user.print();
			
		// 6. user 객체에 대해 changePw수행
			System.out.println("비밀번호 입력하세요");
			user.changePw();
		
	}
}
